<?php

namespace App\Models;

use Illuminate\Support\Facades\DB;
use Jenssegers\Mongodb\Eloquent\Model as Eloquent;
use MongoDB\Laravel\Eloquent\Model;

class Participants extends Model
{
    protected $fillable = ['guest_name', 'email', 'contact', ];

    public function getParticipants()
    {
        return DB::collection('guest')->orderBy('email', 'desc')->get();
    }

    public function saveGuest($data)
    {
        return $this->create($data);
    }

    public function deleteGuest($id)
    {
        return $this->findOrFail($id)->delete();
    }

    public function updateGuest($id)
    {
        return $this->findOrFail($id);
    }

    public function updatedGuest($data, $id)
    {
        return $this->findOrFail($id)->update($data);
    }
}
